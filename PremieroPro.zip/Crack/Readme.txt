Copy all files to installation folder
=================
